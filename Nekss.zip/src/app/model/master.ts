export class Cashier{
   
        financialYearId: number
        btn_name: string
        fromDate: string
        toDate: string
        businessAreaId: string

        constructor(){
            this.financialYearId=0;
            this.btn_name='';
            this.fromDate='';
            this.toDate ='';
            this.businessAreaId='';
        }
      
}





